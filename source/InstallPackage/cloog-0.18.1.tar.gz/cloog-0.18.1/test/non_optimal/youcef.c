/* Generated from ../../../git/cloog/test/non_optimal/youcef.cloog by CLooG 0.14.0-238-gb1cb779 gmp bits in 0.00s. */
for (i=0;i<=5;i++) {
  S1(i,i);
  for (j=i;j<=5;j++) {
    S2(i,j);
  }
  S3(i,5);
}
