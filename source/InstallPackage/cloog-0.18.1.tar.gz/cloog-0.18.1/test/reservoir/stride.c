/* Generated from ../../../git/cloog/test/reservoir/stride.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
if (M >= 2) {
  for (c2=2;c2<=M;c2+=7) {
    S1(c2,(c2-2)/7) ;
  }
}
