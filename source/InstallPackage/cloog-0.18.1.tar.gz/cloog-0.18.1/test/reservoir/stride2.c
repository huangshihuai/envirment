/* Generated from ../../../git/cloog/test/reservoir/stride2.cloog by CLooG 0.16.1-2-g0ae5c85 gmp bits in 0.00s. */
if (M >= 2) {
  for (c2=2;c2<=M;c2+=7) {
    S1(c2,(c2-2)/7);
  }
}
