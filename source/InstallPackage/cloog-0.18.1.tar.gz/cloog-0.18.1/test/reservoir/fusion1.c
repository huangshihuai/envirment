/* Generated from ../../../git/cloog/test/./reservoir/fusion1.cloog by CLooG 0.14.0-136-gb91ef26 gmp bits in 0.00s. */
for (c2=0;c2<=M;c2++) {
  S1(c2) ;
}
for (c2=1;c2<=M;c2++) {
  S2(c2) ;
}
for (c2=0;c2<=M;c2++) {
  S3(c2) ;
}
