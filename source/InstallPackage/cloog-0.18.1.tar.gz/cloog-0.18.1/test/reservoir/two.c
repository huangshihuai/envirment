/* Generated from /home/skimo/git/cloog/test/./reservoir/two.cloog by CLooG 0.14.0-225-g6e2d019 gmp bits in 0.00s. */
S1(1,1,5);
