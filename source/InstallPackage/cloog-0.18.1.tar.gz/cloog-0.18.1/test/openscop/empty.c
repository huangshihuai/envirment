/* Generated from ./test/openscop/empty.scop by CLooG 0.14.0-416-g013422c gmp bits in 0.01s. */
