for (int c0 = 3; c0 <= 9; c0 += 3)
  s0(c0);
