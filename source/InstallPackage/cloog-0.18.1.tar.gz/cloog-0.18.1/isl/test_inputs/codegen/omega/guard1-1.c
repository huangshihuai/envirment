if (n + 2 * floord(-n + m - 1, 2) + 1 == m)
  s0(n, m);
