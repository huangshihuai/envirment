for (int c0 = 1; c0 <= n; c0 += 6)
  for (int c1 = c0; c1 <= n; c1 += 4)
    s0(c0, c1);
