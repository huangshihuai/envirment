for (int c1 = 1; c1 <= M; c1 += 1)
  for (int c3 = 1; c3 <= M; c3 += 1)
    for (int c5 = 1; c5 <= M; c5 += 1)
      for (int c7 = 1; c7 <= M; c7 += 1)
        S1(c3, c5, c1, c7);
