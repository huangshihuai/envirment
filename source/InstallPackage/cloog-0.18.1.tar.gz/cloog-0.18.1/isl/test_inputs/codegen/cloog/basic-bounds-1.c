for (int c0 = 0; c0 <= 2; c0 += 1)
  S1(c0);
