nginx的依赖库
zlib 是 link -> zlib-xx.xx.xx
这是zlib库,根据不同版本创建新的link
